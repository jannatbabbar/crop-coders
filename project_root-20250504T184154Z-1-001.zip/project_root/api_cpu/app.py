from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import random
import hashlib
import jwt
import datetime
import sqlite3
import uuid
import requests
import time

import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../')
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../db/farmers.db')
DB_PATH = os.path.abspath(DB_PATH)

# Import your modules
from scripts.sql_utils import fetch_farmer_details, update_credit_score, fetch_farmer_by_mobile, fetch_lender_by_mobile
from scripts.speech_to_text_inference import speech_to_text
from scripts.translate_text import translate_to_english, translate_to_language
from scripts.predict_credit_score import predict_credit_score
from scripts.loan_recommendation_engine import loan_recommendation_engine
from scripts.offer_generation import fallback_programmatic_offer
from scripts.llama_integration import generate_llama_text, build_loan_offer_prompt, build_ai_contract_prompt
from scripts.text_to_speech import text_to_speech

# Define hash_password function
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Init Flask
app = Flask(__name__)
CORS(app)

SECRET_KEY = os.getenv("SECRET_KEY", "a8d9e2fc674d58b8a2b37b65e4f26e715f6a541f57b73392307ad2a52bb2ac90")
FAKE_OTP_STORE = {}

# GPU Node URL
GPU_NODE_URL = "http://164.52.199.30:6000/"

REGION_LANGUAGE_MAP = {
    'punjab': 'panjabi',
    'karnataka': 'kannada'
}

def hash_otp(otp: str) -> str:
    return hashlib.sha256(otp.encode()).hexdigest()

def translate_to_local_language(english_text, language_code):
    if language_code:
        translated_text = translate_to_language(english_text, language_code)
        return translated_text
    else:
        return english_text

def can_generate_otp(mobile_number):
    otp_data = FAKE_OTP_STORE.get(mobile_number)
    if not otp_data:
        return True  # No OTP generated yet

    current_time = time.time()
    elapsed_time_since_last_otp = current_time - otp_data["timestamp"]
    elapsed_time_since_first_otp = current_time - otp_data["first_otp_time"]

    # Reset OTP count after 30 minutes
    if elapsed_time_since_first_otp > 30:  # 30 minutes = 1800 seconds
        FAKE_OTP_STORE[mobile_number]["count"] = 0
        FAKE_OTP_STORE[mobile_number]["first_otp_time"] = current_time

    if elapsed_time_since_last_otp < 30:
        return False  # Less than 30 seconds since last OTP
    if otp_data["count"] >= 5:
        return False  # Exceeded maximum OTP limit
    return True

def translate_to_local_language(english_text, language_code):
    if language_code:
        translated_text = translate_to_language(english_text, language_code)
        return translated_text
    else:
        return english_text

@app.route('/', methods=['GET'])
def home():
    return jsonify({'message': 'Welcome to the backend of the agri-credit score evaluation!'}), 200

# ======================================
# Farmer Authentication
# ======================================

@app.route('/cpu/farmer-login', methods=['POST'])
def farmer_login():
    mobile_number = request.json.get('mobile_number')
    farmer = fetch_farmer_by_mobile(mobile_number)
    if not farmer:
        return jsonify({'error': 'Mobile number not registered'}), 404

    # Check if OTP can be generated
    if not can_generate_otp(mobile_number):
        return jsonify({'error': 'OTP generation limit reached. Try again later.'}), 429

    otp = f"{random.randint(1000, 9999)}"
    hashed_otp = hash_otp(otp)

    # Update FAKE_OTP_STORE with new OTP and metadata
    current_time = time.time()
    if mobile_number in FAKE_OTP_STORE:
        FAKE_OTP_STORE[mobile_number]["otp"] = hashed_otp
        FAKE_OTP_STORE[mobile_number]["timestamp"] = current_time
        FAKE_OTP_STORE[mobile_number]["count"] += 1
    else:
        FAKE_OTP_STORE[mobile_number] = {
            "otp": hashed_otp,
            "timestamp": current_time,
            "count": 1,
            "first_otp_time": current_time
        }

    print(f"Generated OTP for {mobile_number}: {otp}")
    return jsonify({'message': 'OTP sent (Check Server Logs)', 'otp': otp})

@app.route('/cpu/farmer-verify-otp', methods=['POST'])
def farmer_verify_otp():
    mobile_number = request.json.get('mobile_number')
    otp = request.json.get('otp')

    if FAKE_OTP_STORE.get(mobile_number, {}).get("otp") == hash_otp(otp):
        farmer = fetch_farmer_by_mobile(mobile_number)
        farmer_id = farmer[0]
        farmer_name = farmer[1]  
        state = farmer[5]
        district = farmer[6] 

        return jsonify({
            'farmer_id': farmer_id,
            'farmer_name': farmer_name,
            'state': state,
            'district': district
        })
    else:
        return jsonify({'error': 'Invalid OTP'}), 400

@app.route('/cpu/lender-login', methods=['POST'])
def lender_login():
    mobile_number = request.json.get('mobile_number')
    lender = fetch_lender_by_mobile(mobile_number)
    if not lender:
        return jsonify({'error': 'Mobile number not registered'}), 404

    # Check if OTP can be generated
    if not can_generate_otp(mobile_number):
        return jsonify({'error': 'OTP generation limit reached. Try again later.'}), 429

    otp = f"{random.randint(1000, 9999)}"
    hashed_otp = hash_otp(otp)

    # Update FAKE_OTP_STORE with new OTP and metadata
    current_time = time.time()
    if mobile_number in FAKE_OTP_STORE:
        FAKE_OTP_STORE[mobile_number]["otp"] = hashed_otp
        FAKE_OTP_STORE[mobile_number]["timestamp"] = current_time
        FAKE_OTP_STORE[mobile_number]["count"] += 1
    else:
        FAKE_OTP_STORE[mobile_number] = {
            "otp": hashed_otp,
            "timestamp": current_time,
            "count": 1,
            "first_otp_time": current_time
        }

    print(f"Generated OTP for {mobile_number}: {otp}")
    return jsonify({'message': 'OTP sent (Check Server Logs)', 'otp': otp})

@app.route('/cpu/lender-verify-otp', methods=['POST'])
def lender_verify_otp():
    mobile_number = request.json.get('mobile_number')
    otp = request.json.get('otp')

    if FAKE_OTP_STORE.get(mobile_number, {}).get("otp") == hash_otp(otp):
        lender = fetch_lender_by_mobile(mobile_number)
        lender_id = lender[0]
        lender_name = lender[1] 
        state = lender[3]
        district = lender[4] 
        
        return jsonify({
            'lender_id': lender_id,
            'lender_name': lender_name,
            'state': state,
            'district': district
        })
    else:
        return jsonify({'error': 'Invalid OTP'}), 400

# ======================================
# Speech to Offer
# ======================================

@app.route('/cpu/speech-to-offer', methods=['POST'])
def speech_to_offer():
    audio_file = request.files['audio']
    farmer_id = request.form.get('farmer_id')
    language_from_frontend = request.form.get('language')  # optional

    if not farmer_id:
        return jsonify({"error": "Farmer ID required"}), 400

    audio_path = f"/tmp/{audio_file.filename}"
    audio_file.save(audio_path)

    # Fetch farmer details from the database
    farmer_row = fetch_farmer_details(farmer_id)
    if not farmer_row:
        return jsonify({"error": "Farmer ID not found"}), 404

    # Determine language code based on the farmer's state
    state = farmer_row["State"].lower()  # Assuming state is in the 3rd column of farmer_row
    if state == "punjab":
        language_code = "pa"  # Punjabi
    elif state == "karnataka":
        language_code = "ka"  # Kannada
    else:
        language_code = None  # Default or unsupported state

    # Call speech-to-text with the determined language code
    indic_text = speech_to_text(audio_path, language_code)

    # Translate Indic text to English
    english_text = translate_to_english(indic_text, src_lang=f"{language_code}n_Guru" if language_code == "pa" else f"{language_code}n_Knda")

    english_lower = english_text.lower()

    # Determine intent and call respective methods
    intent = None
    response_data = {}

    if any(keyword in english_lower for keyword in ["credit", "score"]):
        intent = "credit-score"

        credit_score = farmer_row["Credit_Score"]
        if not credit_score or credit_score == 0:

            # Call the get-credit-score API
            credit_score_response = requests.post(
                "http://164.52.192.217:5000/cpu/get-credit-score",  # Update the URL if needed
                json={"farmer_id": farmer_id}
            )
            if credit_score_response.status_code == 200:
                print(response_data.json())
                response_data = credit_score_response.json()
            else:
                response_data = {"error": "Failed to fetch credit score"}

    elif any(keyword in english_lower for keyword in ["loan", "recommendation"]):
        intent = "loan-recommendations"
        # Call the get-loan-recommendation API
        loan_recommendation_response = requests.post(
            "http://164.52.192.217:5000/cpu/get-loan-recommendation",  # Update the URL if needed
            json={"farmer_id": farmer_id}
        )
        if loan_recommendation_response.status_code == 200:
            response_data = loan_recommendation_response.json()
        else:
            response_data = {"error": "Failed to fetch loan recommendations"}

    elif any(keyword in english_lower for keyword in ["view", "offers"]):
        intent = "view-offers"
        # Call the farmer-view-offers API
        view_offers_response = requests.post(
            "http://164.52.192.217:5000/farmer/view-offers",  # Update the URL if needed
            json={"farmer_id": farmer_id}
        )
        if view_offers_response.status_code == 200:
            response_data = view_offers_response.json()
        else:
            response_data = {"error": "Failed to fetch offers"}

    elif any(keyword in english_lower for keyword in ["request", "loan"]):
        intent = "request-loan"
        # Provide a message for requesting a loan
        response_data = {"message": "You can request a loan by providing the required details."}

    else:
        intent = "unknown"
        response_data = {"message": "Sorry, I couldn't understand. Please ask for credit score, loan recommendation, or offers."}

    # Translate response text to local language
    if "message" in response_data:
        response_data["message"] = translate_to_local_language(response_data["message"], language_code = f"{language_code}n_Guru" if language_code == "pa" else f"{language_code}n_Knda")

    # Generate audio output using GPU TTS
    tts_response = text_to_speech(response_data.get("message", ""), language_code)
    audio_output_path = tts_response.get("audio_path", "")

    return jsonify({
        "farmer_id": farmer_id,
        "indic_text": response_data.get("message",""),
        "english_translation": english_text,
        "response_data": response_data,
        "language_used": language_code,
        "intent": intent
    })

# ======================================
# Credit Score
# ======================================

@app.route('/cpu/get-credit-score', methods=['POST'])
def get_credit_score():
    farmer_id = request.json.get('farmer_id')

    farmer_row = fetch_farmer_details(farmer_id)
    if not farmer_row:
        return jsonify({"error": "Farmer not found"}), 404

    credit_score = farmer_row["Credit_Score"]
    if not credit_score or credit_score == 0:
        credit_score = predict_credit_score(farmer_row)
        update_credit_score(farmer_id, credit_score)

    return jsonify({"farmer_id": farmer_id, "credit_score": credit_score})

# ======================================
# Loan Recommendation
# ======================================

@app.route('/cpu/get-loan-recommendation', methods=['POST'])
def get_loan_recommendation():
    farmer_id = request.json.get('farmer_id')

    # Fetch farmer details
    farmer_row = fetch_farmer_details(farmer_id)
    if not farmer_row:
        return jsonify({"error": "Farmer not found"}), 404

    # Calculate credit score if missing
    credit_score = farmer_row["Credit_Score"]
    if not credit_score or credit_score == 0:
        credit_score = predict_credit_score(farmer_row)
        update_credit_score(farmer_id, credit_score)

    net_income = farmer_row["Net_Income"]

    # Generate base loan offer
    base_offer = loan_recommendation_engine({
        "Credit_Score": credit_score,
        "Landholding_Size_ha": farmer_row["Landholding_Size_ha"],
        "Net_Income": net_income,
        "Insurance_Availed": farmer_row["Insurance_Availed"],
        "FPO_Member": farmer_row["FPO_Member"],
        "Crop_Grown": farmer_row["Crop_Grown"]
    })

    # Build prompt for dynamic response
    prompt = build_loan_offer_prompt({
        "credit_score": credit_score,
        "net_income": net_income,
        "caste": farmer_row["Caste"],
        "gender": farmer_row["Gender"],
        "district": farmer_row["District"],
        "state": farmer_row["State"]
    })

    # Request dynamic text from GPU node
    try:
        response = requests.post(f"{GPU_NODE_URL}gpu/generate-loan-offer", json={"prompt": prompt})
        response.raise_for_status()
        dynamic_offer_text = response.json().get("text")
    except requests.RequestException as e:
        print(f"[ERROR] Loan generation failed: {str(e)}")
        dynamic_offer_text = fallback_programmatic_offer(
            credit_score, net_income, farmer_row["District"], farmer_row["State"]
        )

    # Final structured response
    return jsonify({
        "farmer_id": farmer_id,
        "credit_score": credit_score,
        "recommended_loan_amount": base_offer["recommended_amount"],
        "recommended_interest_rate": base_offer["interest_rate"],
        "eligible_interest_range": base_offer["interest_rate_range"],
        "loan_amount_ranges": base_offer["loan_amount_ranges"],
        "eligible_schemes": {
            "by_government": ["PM-Kisan", "PM Fasal Bima Yojana", "NABARD Agricultural Loan"],
            "by_banks": ["MUDRA Loan"]
        },
        "dynamic_offer_text": dynamic_offer_text
    })


# Request loan
@app.route('/farmer/request-loan', methods=['POST'])
def request_loan():
   data = request.json
   farmer_id = data.get('farmer_id')
   loan_amount = data.get('amount')
   interest_rate = data.get('interest_rate')  # now expecting a number (e.g. 6.5)
   duration = data.get('duration')  # now expecting months as integer

   # Validate input
   if not all([farmer_id, loan_amount, interest_rate, duration]):
       return jsonify({'error': 'Missing required fields'}), 400

   try:
       # Create a unique loan_request_id
       loan_request_id = str(uuid.uuid4())

       conn = sqlite3.connect(DB_PATH)
       cursor = conn.cursor()

       cursor.execute('''
           INSERT INTO loan_requests (loan_request_id, farmer_id, loan_amount, interest_rate, duration_in_months)
           VALUES (?, ?, ?, ?, ?)
       ''', (loan_request_id, farmer_id, loan_amount, interest_rate, duration))

       conn.commit()
       conn.close()

       return jsonify({'message': 'Loan request submitted successfully', 'loan_request_id': loan_request_id}), 200


   except Exception as e:
       return jsonify({'error': str(e)}), 500

# ======================================
# AI Contract Generation
# ======================================

@app.route('/cpu/request-ai-contract', methods=['POST'])
def request_ai_contract():
    # Extract farmer_id from the incoming request
    farmer_id = request.json.get('farmer_id')

    # Fetch farmer details from the database
    farmer_row = fetch_farmer_details(farmer_id)
    if not farmer_row:
        return jsonify({"error": "Farmer not found"}), 404

    # Build the AI contract prompt using the fetched farmer details
    prompt = build_ai_contract_prompt({
        "farmer_name": farmer_row["Farmer_Name"],
        "lender_name": "Bank",  # default placeholder for lender name
        "loan_amount": 150000,
        "interest_rate": 7.5,
        "district": farmer_row["District"],
        "state": farmer_row["State"]
    })

    # Debug: Print out the generated prompt to check the format
    print("Generated AI Contract Prompt:", prompt)

    # Request the GPU node to generate the AI contract using the LLaMA model
    try:
        response = requests.post(
            f"{GPU_NODE_URL}gpu/generate-ai-contract",  # Use the GPU node URL for contract generation
            json={"prompt": prompt}
        )
        response.raise_for_status()  # Check for HTTP errors

        # Extract the contract text from the response
        contract_text = response.json().get("ai_contract")

        # If contract text is empty, handle it gracefully
        if not contract_text:
            return jsonify({"error": "Failed to generate a valid AI contract"}), 500
    except requests.RequestException as e:
        return jsonify({"error": f"Failed to generate AI contract: {str(e)}"}), 500

    # Return the generated AI contract
    return jsonify({
        "farmer_id": farmer_id,
        "ai_contract": contract_text
    })

# ========== LENDER MODULE ==========

# ========== LENDER MODULE ==========

@app.route('/lender/loan-requests-by-region', methods=['POST'])  # Changed to POST
def loan_requests_by_region():
    data = request.json
    region = data.get('region')

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Enable access by column name
    cursor = conn.cursor()

    query = '''
    SELECT 
        lr.loan_request_id,
        f.Farmer_Name,
        lr.loan_amount,
        lr.interest_rate,
        lr.duration_in_months
    FROM 
        farmers f
    JOIN 
        loan_requests lr ON f.Farmer_ID = lr.farmer_id
    WHERE 
        f.State LIKE ?
    '''

    cursor.execute(query, ('%' + region + '%',))
    loan_requests = cursor.fetchall()
    conn.close()

    result = []
    for lr in loan_requests:
        result.append({
            "loan_request_id": lr["loan_request_id"],
            "farmer_name": lr["Farmer_Name"],
            "loan_amount": lr["loan_amount"],
            "interest_rate": lr["interest_rate"],
            "duration": lr["duration_in_months"]
        })

    return jsonify(result)

@app.route('/lender/send-offer', methods=['POST'])
def send_offer():
    data = request.json
    lender_id = data.get('lender_id')
    farmer_id = data.get('farmer_id')
    loan_request_id = data.get('loan_request_id')
    offered_interest_rate = data.get('offered_interest_rate')

    offer_id = str(uuid.uuid4())

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO loan_offers (offer_id, lender_id, farmer_id, loan_request_id, offered_interest_rate) VALUES (?, ?, ?, ?, ?)",
                   (offer_id, lender_id, farmer_id, loan_request_id, offered_interest_rate))
    conn.commit()
    conn.close()

    return jsonify({"offer_id": offer_id})

@app.route('/lender/view-sent-offers', methods=['POST'])  # Changed to POST
def view_sent_offers():
    data = request.json
    lender_id = data.get('lender_id')

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Enable access by column name
    cursor = conn.cursor()

    cursor.execute('''
        SELECT 
            loan_offers.offer_id,
            loan_offers.farmer_id,
            loan_requests.loan_amount,
            loan_requests.duration_in_months,
            loan_offers.offered_interest_rate,
            loan_offers.status
        FROM loan_offers
        JOIN loan_requests ON loan_offers.loan_request_id = loan_requests.loan_request_id
        WHERE loan_offers.lender_id = ?
    ''', (lender_id,))

    offers = cursor.fetchall()
    conn.close()

    offers_list = []
    for o in offers:
        offers_list.append({
            "offer_id": o["offer_id"],
            "farmer_id": o["farmer_id"],
            "loan_amount": o["loan_amount"],
            "duration_in_months": o["duration_in_months"],
            "interest_rate": o["offered_interest_rate"],
            "status": o["status"]
        })

    return jsonify(offers_list)

@app.route('/farmer/view-offers', methods=['POST'])  # Changed to POST
def farmer_view_offers():
    data = request.json
    farmer_id = data.get('farmer_id')

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Enable access by column name
    cursor = conn.cursor()

    cursor.execute('''
        SELECT 
            loan_offers.offer_id,
            lenders.lender_name AS lender_name,
            loan_offers.offered_interest_rate,
            loan_offers.status,
            loan_requests.loan_amount,
            loan_requests.duration_in_months
        FROM loan_offers
        JOIN lenders ON loan_offers.lender_id = lenders.lender_id
        JOIN loan_requests ON loan_offers.loan_request_id = loan_requests.loan_request_id
        WHERE loan_requests.farmer_id = ? AND loan_offers.status = 'pending'
    ''', (farmer_id,))

    offers = cursor.fetchall()
    conn.close()

    offers_list = []
    for offer in offers:
        offers_list.append({
            "offer_id": offer["offer_id"],
            "lender_name": offer["lender_name"],
            "interest_rate": offer["offered_interest_rate"],
            "status": offer["status"],
            "amount": offer["loan_amount"],
            "duration": offer["duration_in_months"]
        })

    return jsonify(offers_list)

@app.route('/farmer/accept-offer', methods=['POST'])
def accept_offer():
    data = request.json
    offer_id = data.get('offer_id')

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Enable access by column name
    cursor = conn.cursor()
    cursor.execute("UPDATE loan_offers SET status='accepted' WHERE offer_id=?", (offer_id,))
    conn.commit()

    # Fetch offer details
    cursor.execute("SELECT lender_id, farmer_id FROM loan_offers WHERE offer_id=?", (offer_id,))
    offer = cursor.fetchone()

    if offer:
        lender_id = offer["lender_id"]
        farmer_id = offer["farmer_id"]
        prompt = f"Generate a loan contract between lender {lender_id} and farmer {farmer_id}."
        # contract_text = generate_llama_text(prompt)

        # contract_id = str(uuid.uuid4())
        # cursor.execute("INSERT INTO accepted_contracts (contract_id, offer_id, farmer_id, lender_id, contract_text) VALUES (?, ?, ?, ?, ?)",
        #               (contract_id, offer_id, farmer_id, lender_id, contract_text))
        # conn.commit()

    conn.close()

    return jsonify({"status": "Offer accepted"})

@app.route('/farmer/reject-offer', methods=['POST'])
def reject_offer():
    data = request.json
    offer_id = data.get('offer_id')

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE loan_offers SET status='rejected' WHERE offer_id=?", (offer_id,))
    conn.commit()
    conn.close()

    return jsonify({"status": "Offer rejected"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
