# AgriCredit Platform: Farmers and Lenders

A real-world end-to-end system for farmer credit scoring, personalized loan recommendation, lender-farmer marketplace, and AI contract generation, fully integrated with speech-to-text and regional language support.

---

# 📦 Project Structure

```plaintext
/project-root/
│
├── /scripts/                    # Utility scripts for ML, STT, TTS, Translation
│     ├── sql_utils.py
│     ├── predict_credit_score.py
│     ├── speech_to_text_inference.py
│     ├── translate_text.py
│     ├── text_to_speech.py
│     ├── loan_recommendation_engine.py
│     ├── offer_generation.py
│     ├── llama_integration.py
│
├── /api_cpu/                     # CPU Node - Farmer + Lender Flask Server
│     ├── app.py
│
├── /api_gpu/                     # GPU Node - STT, TTS, Llama Flask Server
│     ├── app.py
│
├── /model/                       # Pretrained Models
│     ├── credit_score_model.pkl
│
├── /db/                          # Database Folder
│     ├── farmers.db (created after db_setup.py)
│
├── db_setup.py                   # Script to create database schema
├── dummy_seed_data.py             # Script to seed dummy farmers and lenders
├── requirements_cpu.txt           # CPU Requirements
├── requirements_gpu.txt           # GPU Requirements
├── run_server_cpu.sh              # Bash script to run CPU server
├── run_server_gpu.sh              # Bash script to run GPU server
├── README.md                      # This file
```

---

# 🛠 Setup Instructions

---

## 1. Upload Project to E2E Networks

* Upload `project-root.zip` to your CPU Node and GPU Node.
* Unzip on both servers:

```bash
unzip project-root.zip
```

---

## 2. CPU Node Setup

* Install dependencies:

```bash
pip install -r requirements_cpu.txt
```

* Prepare database:

```bash
python3 db_setup.py
python3 dummy_seed_data.py
```

* Start CPU Flask Server:

```bash
bash run_server_cpu.sh
```

✅ Runs on `http://<CPU_NODE_IP>:5000/`

---

## 3. GPU Node Setup

* Install dependencies:

```bash
pip install -r requirements_gpu.txt
```

* Start GPU Flask Server:

```bash
bash run_server_gpu.sh
```

✅ Runs on `http://<GPU_NODE_IP>:6000/`

---

# 📡 API Summary

---

## CPU Node APIs (`http://<cpu_node_ip>:5000/`)

### Farmer APIs

| Endpoint                       | Method | Description                                                  |
| :----------------------------- | :----- | :----------------------------------------------------------- |
| `/cpu/speech-to-offer`         | POST   | Farmer Speech → Text → Predict Credit Score → Recommend Loan |
| `/cpu/get-credit-score`        | POST   | Get Credit Score of a Farmer                                 |
| `/cpu/get-loan-recommendation` | POST   | Get Recommended Loan for Farmer                              |
| `/cpu/view-loan-offers`        | GET    | Farmer views pending offers                                  |
| `/cpu/request-ai-contract`     | POST   | Farmer accepts loan offer → Generate Contract                |

---

### Lender APIs

| Endpoint                    | Method | Description                     |
| :-------------------------- | :----- | :------------------------------ |
| `/lender/register`          | POST   | Lender registration             |
| `/lender/login`             | POST   | Lender login                    |
| `/lender/farmers-by-region` | POST   | View farmers by selected region |
| `/lender/send-offer`        | POST   | Send loan offer to farmer       |
| `/lender/view-sent-offers`  | GET    | View all offers sent            |

---

## GPU Node APIs (`http://<gpu_node_ip>:6000/`)

| Endpoint                    | Method | Description                                |
| :-------------------------- | :----- | :----------------------------------------- |
| `/gpu/speech-to-text`       | POST   | Whisper Tiny model STT                     |
| `/gpu/text-to-speech`       | POST   | Text-to-speech output in regional language |
| `/gpu/generate-loan-offer`  | POST   | Generate loan offer text via Llama         |
| `/gpu/generate-ai-contract` | POST   | Generate full AI contract via Llama        |

---

# 🧠 Technical Notes

* Farmer IDs like `F00001`, `F00002`, etc.
* Lender login uses SHA256 password hash storage (safe even in demo).
* Whisper Tiny model is used for fast, light STT.
* Llama (3B or Tiny) is used for loan offers and contract generation.
* SQLite Database (farmers.db) stores all:

  * Farmers
  * Lenders
  * Offers
  * Accepted Contracts
* Farmers can accept only one offer.
* Contracts saved permanently in DB after acceptance.

---

# 💻 Frontend (React)

* Mic Input → `/cpu/speech-to-offer`
* Button Click (Manual) → `/cpu/get-credit-score`, `/cpu/get-loan-recommendation`
* Farmer Offer Page → `/cpu/view-loan-offers`
* Lender Dashboard → `/lender/view-sent-offers`

✅ Frontend can easily call all endpoints.

---

# ⚡ Credits Optimization (for E2E Portal)

* CPU Node: Small instance (only Flask + SQLite)
* GPU Node: Small to Medium instance (only Whisper Tiny + small Llama)
* Caching Llama models on first request using GPU memory (keep flask app warm)
* If needed, we can optimize by batching farmer profile loads.

---

# 📣 Deployment Commands Quick Summary

```bash
# CPU Node
bash run_server_cpu.sh

# GPU Node
bash run_server_gpu.sh

# Prepare Database
python3 db_setup.py
python3 dummy_seed_data.py