#!/bin/bash
sudo apt update -y
sudo apt install python3-pip -y
pip3 install -r requirements_cpu.txt
cd api_cpu
python3 app.py
