import os
import sys

from flask import Flask, request, jsonify
from transformers import pipeline, AutoModelForSeq2SeqLM, AutoTokenizer

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../IndicTrans2/huggingface_interface'))

from IndicTransToolkit.IndicTransToolkit.processor import IndicProcessor
import torch

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../')

from scripts.llama_integration import generate_llama_text

app = Flask(__name__)

# Load models once at startup
stt_pipeline = pipeline("automatic-speech-recognition", model="openai/whisper-medium")
tts_pipeline = pipeline("text-to-speech", model="ai4bharat/indic-parler-tts")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Load the English-to-Indic translation model and tokenizer
en_to_indic_model_name = "ai4bharat/indictrans2-en-indic-1B"
en_to_indic_tokenizer = AutoTokenizer.from_pretrained(en_to_indic_model_name, trust_remote_code=True)
en_to_indic_model = AutoModelForSeq2SeqLM.from_pretrained(
    en_to_indic_model_name,
    trust_remote_code=True,
    torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
    attn_implementation="flash_attention_2" if DEVICE == "cuda" else None
).to(DEVICE)

# Load the Indic-to-English translation model and tokenizer
indic_to_en_model_name = "ai4bharat/indictrans2-indic-en-1B"
indic_to_en_tokenizer = AutoTokenizer.from_pretrained(indic_to_en_model_name, trust_remote_code=True)
indic_to_en_model = AutoModelForSeq2SeqLM.from_pretrained(
    indic_to_en_model_name,
    trust_remote_code=True,
    torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
    attn_implementation="flash_attention_2" if DEVICE == "cuda" else None
).to(DEVICE)

ip = IndicProcessor(inference=True)

@app.route('/gpu/translate-to-english', methods=['POST'])
def translate_to_english():
    data = request.json
    text = data.get('text')
    src_lang = data.get('src_lang')  # e.g., "pan_Guru" for Punjabi, "kan_Knda" for Kannada

    if not text or not src_lang:
        return jsonify({"error": "Both 'text' and 'src_lang' are required"}), 400
    print(text)
    # Preprocess the input text
    batch = ip.preprocess_batch([text], src_lang=src_lang, tgt_lang="eng_Latn")

    # Tokenize and generate translation
    inputs = indic_to_en_tokenizer(batch, return_tensors="pt", padding=True).to(DEVICE)
    with torch.no_grad():
        generated_tokens = indic_to_en_model.generate(**inputs, max_length=256, num_beams=5)
    translated_text = indic_to_en_tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]

    return jsonify({"translated_text": translated_text})

@app.route('/gpu/translate-to-language', methods=['POST'])
def translate_to_language():
    data = request.json
    text = data.get('text')
    tgt_lang = data.get('tgt_lang')  # e.g., "pan_Guru" for Punjabi, "kan_Knda" for Kannada

    if not text or not tgt_lang:
        return jsonify({"error": "Both 'text' and 'tgt_lang' are required"}), 400

    # Preprocess the input text
    batch = ip.preprocess_batch([text], src_lang="eng_Latn", tgt_lang=tgt_lang)

    # Tokenize and generate translation
    inputs = en_to_indic_tokenizer(batch, return_tensors="pt", padding=True).to(DEVICE)
    with torch.no_grad():
        generated_tokens = en_to_indic_model.generate(**inputs, max_length=256, num_beams=5)
    translated_text = en_to_indic_tokenizer.batch_decode(generated_tokens, skip_special_tokens=True)[0]

    return jsonify({"translated_text": translated_text})

@app.route('/gpu/speech-to-text', methods=['POST'])
def gpu_speech_to_text():
    audio_file = request.files['audio']
    audio_path = f"/tmp/{audio_file.filename}"
    audio_file.save(audio_path)

    text_output = stt_pipeline(audio_path)
    return jsonify({"text": text_output['text']})

@app.route('/gpu/text-to-speech', methods=['POST'])
def gpu_text_to_speech():
    text = request.json.get('text')

    if not text:
        return jsonify({"error": "Text is required for TTS"}), 400

    # Generate speech using the TTS pipeline
    try:
        speech = tts_pipeline(text)
    except Exception as e:
        return jsonify({"error": f"Failed to generate speech: {str(e)}"}), 500

    # Save the audio to a file
    output_audio_path = f"/tmp/output_{text[:10]}.wav"
    with open(output_audio_path, "wb") as f:
        f.write(speech["audio"])

    return jsonify({"audio_path": output_audio_path})

@app.route('/gpu/generate-loan-offer', methods=['POST'])
def gpu_generate_loan_offer():
    prompt = request.json.get('prompt')

    if not prompt:
        return jsonify({"error": "Missing required field: 'prompt'"}), 400

    # Generate dynamic loan offer using LLaMA
    try:
        dynamic_offer_text = generate_llama_text(prompt)
    except Exception as e:
        print(f"Failed to generate dynamic loan offer: {str(e)}")
        return jsonify({"error": f"Failed to generate dynamic loan offer: {str(e)}"}), 500

    return jsonify({
        "dynamic_offer_text": dynamic_offer_text
    })

@app.route('/gpu/generate-ai-contract', methods=['POST'])
def gpu_generate_ai_contract():
    # Extract the prompt from the incoming request
    prompt = request.json.get('prompt')

    if not prompt:
        return jsonify({"error": "Missing required field: 'prompt'"}), 400

    # Debug: Print the received prompt to verify its contents
    print("Received AI Contract Prompt:", prompt)

    # Generate the AI contract using LLaMA
    try:
        contract_text = generate_llama_text(prompt)
    except Exception as e:
        print(f"Error in generating AI contract: {str(e)}")
        return jsonify({"error": f"Failed to generate AI contract: {str(e)}"}), 500

    # Return the generated AI contract as a response
    return jsonify({
        "ai_contract": contract_text
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)