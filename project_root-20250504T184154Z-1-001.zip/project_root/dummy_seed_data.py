import sqlite3
import pandas as pd
import random
import os

def generate_mobile_number():
    """Generate a random mobile number starting with 9."""
    return f"9{random.randint(100000000, 999999999)}"

def load_farmers_data(filepath):
    """Load the farmers dataset from a CSV file."""
    farmers_df = pd.read_csv(filepath)

    # Clean Landholding_Size_ha column
    farmers_df['Landholding_Size_ha'] = pd.to_numeric(farmers_df['Landholding_Size_ha'], errors='coerce')

    return farmers_df

def insert_farmers(cursor, farmers_df):
    for _, row in farmers_df.iterrows():

        # Debugging: Print row to verify data
        print(row['Landholding_Size_ha'], row['Education_Level'])  # Add this line to debug

        mobile_number = generate_mobile_number()
        cursor.execute('''
            INSERT OR IGNORE INTO farmers (
                Farmer_ID, Farmer_Name, Gender, Caste, State, District, Season, District_Weather,
                Average_Temperature_C, Average_Rainfall_mm, Farmer_Age, Education_Level,
                Land_Ownership_Type, Landholding_Size_ha, Crop_Grown, Crop_Risk_Score,
                Crop_Yield_kg_per_ha, Sale_Price_per_kg, Gross_Income, Input_Cost, Net_Income,
                Monthly_Family_Expense, Net_Disposable_Income, Loan_Taken, Loan_Status,
                Access_to_Irrigation, Insurance_Availed, Crop_Season_Shock,
                Modern_Agri_Techniques_Used, Horticulture_Farmer, FPO_Member, Off_Farm_Income,
                Outlier_Flag, Mobile_Number
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ''', (
            row['Farmer_ID'], row['Farmer_Name'], row['Gender'], row['Caste'], row['State'], row['District'],
            row['Season'], row['District_Weather'], row['Average_Temperature_C'], row['Average_Rainfall_mm'],
            row['Farmer_Age'], row['Education_Level'], row['Land_Ownership_Type'], row['Landholding_Size_ha'],
            row['Crop_Grown'], row['Crop_Risk_Score'], row['Crop_Yield_kg_per_ha'], row['Sale_Price_per_kg'],
            row['Gross_Income'], row['Input_Cost'], row['Net_Income'], row['Monthly_Family_Expense'],
            row['Net_Disposable_Income'], row['Loan_Taken'], row['Loan_Status'], row['Access_to_Irrigation'],
            row['Insurance_Availed'], row['Crop_Season_Shock'], row['Modern_Agri_Techniques_Used'],
            row['Horticulture_Farmer'], row['FPO_Member'], row['Off_Farm_Income'], row['Outlier_Flag'],
            mobile_number  # Ensure this is the last value
        ))

def insert_dummy_lenders(cursor):
    """Insert 100 unique informal lenders into the database."""
    punjabi_first_names = ["Aman", "Baljit", "Charanjit", "Deepak", "Ekta", "Fateh", "Gurpreet", "Harjit", "Inderjit", "Jaspreet"]
    punjabi_last_names = ["Singh", "Kaur", "Sharma", "Gill", "Dhillon", "Sidhu", "Sandhu", "Bajwa", "Brar", "Chahal"]

    kannada_first_names = ["Anand", "Bharath", "Chandru", "Deepak", "Eshwar", "Ganesh", "Harsha", "Ishwar", "Jagadish", "Kiran"]
    kannada_last_names = ["Kumar", "Gowda", "Shetty", "Reddy", "Naik", "Hegde", "Patil", "Desai", "Rao", "Shenoy"]

    states = ["Punjab", "Karnataka"]
    districts = {
        "Punjab": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda"],
        "Karnataka": ["Bangalore", "Mysore", "Mandya", "Hubli", "Mangalore"]
    }

    dummy_lenders = []
    for i in range(1, 101):
        lender_id = f"L{i:03}"  # Generate lender IDs like L001, L002, ..., L100
        state = random.choice(states)  # Randomly choose between Punjab and Karnataka
        district = random.choice(districts[state])  # Random district based on state

        # Generate unique lender names by combining first and last names
        if state == "Punjab":
            first_name = random.choice(punjabi_first_names)
            last_name = random.choice(punjabi_last_names)
        else:  # Karnataka
            first_name = random.choice(kannada_first_names)
            last_name = random.choice(kannada_last_names)

        lender_name = f"{first_name} {last_name}"  # Combine first and last names
        mobile_number = f"9{random.randint(100000000, 999999999)}"  # Random mobile number starting with 9
        dummy_lenders.append((lender_name, mobile_number, state, district))

    for lender in dummy_lenders:
        cursor.execute('''
            INSERT OR IGNORE INTO lenders (lender_name, mobile_number, state, district)
            VALUES (?,?,?,?)
        ''', lender)

def seed_database():
    """Seed the database with farmers and lenders data."""
    if not os.path.exists('db'):
        os.makedirs('db')

    conn = sqlite3.connect('db/farmers.db')
    cursor = conn.cursor()

    # Load and insert farmers data
    farmers_df = load_farmers_data('db/synthetic_farmers_dataset.csv')
    insert_farmers(cursor, farmers_df)

    # Insert dummy lenders
    insert_dummy_lenders(cursor)

    conn.commit()
    conn.close()
    print("Dummy farmers and lenders inserted into the database with full columns.")

if __name__ == "__main__":
    seed_database()