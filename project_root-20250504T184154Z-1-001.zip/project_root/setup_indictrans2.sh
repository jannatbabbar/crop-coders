#!/bin/bash

# Check if IndicTrans2 is already set up
if [ -d "IndicTrans2" ]; then
    echo "IndicTrans2 is already set up. Skipping installation."
    exit 0
fi

# Clone the IndicTrans2 repository
echo "Cloning IndicTrans2 repository..."
git clone https://github.com/AI4Bharat/IndicTrans2.git

# Run the installation script
echo "Running IndicTrans2 installation script..."
cd IndicTrans2/huggingface_interface/
bash install.sh
cd ../../  # Return to the root directory

echo "IndicTrans2 setup completed."