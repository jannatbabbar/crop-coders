def loan_recommendation_engine(row):
    credit_score = float(row['Credit_Score'])

    print("Credit Score:", credit_score)

    land_size = row['Landholding_Size_ha']
    net_income = float(row['Net_Income'])
    insured = row['Insurance_Availed'] == "Yes"
    fpo_member = row['FPO_Member'] == "Yes"
    crop = row.get('Crop_Grown', '')

    # Determine the base interest rate based on credit score (with government subsidies applied)
    if credit_score >= 650:
        base_interest = 7.0
        interest_range = (6.5, 8.0)
    elif credit_score >= 550:
        base_interest = 8.0
        interest_range = (7.5, 9.5)
    elif credit_score >= 450:
        base_interest = 10.0
        interest_range = (9.5, 11.0)
    else:
        base_interest = 11.5
        interest_range = (10.5, 12.0)

    # Apply subsidy for government schemes
    if row['Insurance_Availed'] == "Yes" or row['FPO_Member'] == "Yes":
        base_interest -= 0.5  # Apply a small discount for insured or FPO members
        interest_range = (interest_range[0] - 0.5, interest_range[1] - 0.5)

    # Ensure the base interest does not go below a minimum threshold
    base_interest = max(base_interest, 4.0)
    interest_range = (max(interest_range[0], 4.0), max(interest_range[1], 4.0))

    # Calculate loan amount based on income (1x, 2x, 3x of annual income)
    loan_ranges = {
        "1x Income Loan": int(net_income),
        "2x Income Loan": int(net_income * 2),
        "3x Income Loan": int(net_income * 3)
    }

    # Set eligible government schemes based on input (these could change based on actual data)
    eligible_schemes = ["PM-Kisan", "PM Fasal Bima Yojana", "MUDRA Loan", "NABARD Agricultural Loan"]

    # Construct the loan recommendation response
    recommendation = {
        "tier": get_credit_tier(credit_score),  # This returns "Prime", "Standard", "Sub-prime", or "High Risk"
        "interest_rate": f"{base_interest}%",
        "interest_rate_range": f"{interest_range[0]}% to {interest_range[1]}%",
        "recommended_amount": loan_ranges["1x Income Loan"],  # Recommended loan is 1x the annual income
        "loan_amount_ranges": loan_ranges,
        "eligible_schemes": eligible_schemes
    }

    return recommendation

def get_credit_tier(credit_score):
    # Determine the credit tier based on the score
    if credit_score >= 650:
        return "Prime"
    elif credit_score >= 550:
        return "Standard"
    elif credit_score >= 450:
        return "Sub-prime"
    else:
        return "High Risk"
