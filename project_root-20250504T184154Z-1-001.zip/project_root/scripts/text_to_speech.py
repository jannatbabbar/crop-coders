import requests

GPU_NODE_URL = "http://164.52.199.30:6000/"

def text_to_speech(text):
    url = f"{GPU_NODE_URL}/gpu/text-to-speech"
    response = requests.post(url, json={"text": text})
    return response.json().get('audio_path', '')