import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBRegressor
import joblib

# Load Dataset
df = pd.read_csv('synthetic_farmers_dataset.csv')
print(f"Dataset Loaded. Rows: {df.shape[0]}")

# Clean numeric fields
numeric_fields = [
    'Farmer_Age', 'Landholding_Size_ha', 'Crop_Risk_Score', 'Crop_Yield_kg_per_ha',
    'Sale_Price_per_kg', 'Gross_Income', 'Input_Cost', 'Net_Income',
    'Monthly_Family_Expense', 'Net_Disposable_Income', 'Off_Farm_Income'
]

for col in numeric_fields:
    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

# Label Encode Categorical fields with 'Unknown' added
categorical_fields = [
    "State", "District", "Season", "Education_Level", "Land_Ownership_Type",
    "Crop_Grown", "Loan_Status", "Access_to_Irrigation", "Insurance_Availed",
    "District_Weather", "Crop_Season_Shock", "Modern_Agri_Techniques_Used",
    "Loan_Taken", "Horticulture_Farmer", "FPO_Member", "Outlier_Flag"
]

X = df.copy()
label_encoders = {}

for col in categorical_fields:
    le = LabelEncoder()
    unique_vals = X[col].astype(str).unique().tolist()
    if "Unknown" not in unique_vals:
        unique_vals.append("Unknown")
    le.fit(unique_vals)
    X[col] = le.transform(X[col].astype(str))
    label_encoders[col] = le

# Final Features
feature_cols = numeric_fields + categorical_fields
X_model = X[feature_cols]

# Step 1: Clip negative income
X['Net_Disposable_Income'] = X['Net_Disposable_Income'].clip(lower=0)

# Step 2: New Composite Target
y_raw = (
    0.6 * np.log1p(X['Net_Disposable_Income']) + 
    0.2 * (X['Loan_Status'].apply(lambda x: 1 if x == 'Repaid' else 0)) +
    0.2 * (X['Access_to_Irrigation'].apply(lambda x: 1 if x == 'Yes' else 0))
).clip(lower=0, upper=10)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X_model, y_raw, test_size=0.2, random_state=42)

# Model Training
model = XGBRegressor(
    n_estimators=300,
    max_depth=6,
    learning_rate=0.05,
    random_state=42
)
model.fit(X_train, y_train)

# Save Model
joblib.dump(model, 'credit_score_model.pkl')
print("Credit Score Model trained and saved as 'credit_score_model.pkl'.")