import sqlite3
import os

# Dynamically construct the absolute path to the database file
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../db/farmers.db')
DB_PATH = os.path.abspath(DB_PATH)

# Fetch farmer details by Farmer ID
def fetch_farmer_details(farmer_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM farmers WHERE Farmer_ID = ?", (farmer_id,))
    farmer = cursor.fetchone()
    conn.close()
    return dict(farmer) if farmer else None

def fetch_farmer_by_mobile(mobile_number):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM farmers WHERE mobile_number=?", (mobile_number,))
    farmer = cursor.fetchone()

    conn.close()
    return farmer

def fetch_lender_by_mobile(mobile_number):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM lenders WHERE mobile_number=?", (mobile_number,))
    lender = cursor.fetchone()

    conn.close()
    return lender

# Update Credit Score in Farmers DB
def update_credit_score(farmer_id, credit_score):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE farmers SET Credit_Score=? WHERE Farmer_ID=?", (credit_score, farmer_id))
    conn.commit()
    conn.close()
