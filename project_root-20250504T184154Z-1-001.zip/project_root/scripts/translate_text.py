import requests

# GPU Node URL
GPU_NODE_URL = "http://164.52.199.30:6000/"

def translate_to_english(text, src_lang):
    """
    Translate text from Indic language to English using the GPU service.
    :param text: Input text in Indic language.
    :param src_lang: Source language code (e.g., "pan_Guru" for Punjabi, "kan_Knda" for Kannada).
    :return: Translated text in English.
    """
    url = f"{GPU_NODE_URL}/gpu/translate-to-english"
    payload = {"text": text, "src_lang": src_lang}
    try:
        response = requests.post(url, json=payload)
        if response.status_code == 200:
            print(response.json())
            return response.json().get("translated_text", "")
        else:
            return f"Error: {response.json().get('error', 'Translation failed')}"
    except Exception as e:
        return f"Error: {str(e)}"

def translate_to_language(text, target_lang):
    """
    Translate text from English to a regional Indic language using the GPU service.
    :param text: Input text in English.
    :param target_lang: Target language code (e.g., "pan_Guru" for Punjabi, "kan_Knda" for Kannada).
    :return: Translated text in the target Indic language.
    """
    url = f"{GPU_NODE_URL}/gpu/translate-to-language"
    payload = {"text": text, "tgt_lang": target_lang}
    try:
        response = requests.post(url, json=payload)
        if response.status_code == 200:
            return response.json().get("translated_text", "")
        else:
            return f"Error: {response.json().get('error', 'Translation failed')}"
    except Exception as e:
        return f"Error: {str(e)}"