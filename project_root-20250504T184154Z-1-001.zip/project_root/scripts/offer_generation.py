def fallback_programmatic_offer(credit_score, net_income, district, state):
    # Tiered interest rate logic based on updated fairer policy
    if credit_score >= 650:
        base_interest = 7.0
        interest_range = (6.5, 7.5)
    elif credit_score >= 550:
        base_interest = 8.0
        interest_range = (7.5, 8.5)
    elif credit_score >= 450:
        base_interest = 9.0
        interest_range = (8.5, 9.5)
    else:
        base_interest = 9.5
        interest_range = (9.0, 10.0)

    # Loan ranges
    loan_ranges = {
        "1x_income": int(net_income),
        "2x_income": int(net_income * 2),
        "3x_income": int(net_income * 3)
    }

    # Default eligible schemes (assumed based on relevance)
    government_schemes = [
        "PM-Kisan",
        "PM Fasal Bima Yojana (PMFBY)",
        "NABARD Agricultural Loan"
    ]

    bank_schemes = [
        "MUDRA Loan",
        "Kisan Credit Card (KCC)"
    ]

    # Summary fallback text
    offer_text = f"""
- Recommended Interest Rate: {base_interest}%
- Eligible Interest Rate Range: {interest_range[0]}% to {interest_range[1]}%
- Loan Amount Ranges:
    • 1x Income: ₹{loan_ranges['1x_income']}
    • 2x Income: ₹{loan_ranges['2x_income']}
    • 3x Income: ₹{loan_ranges['3x_income']}

- Government Schemes:
    • {', '.join(government_schemes)}

- Bank Schemes:
    • {', '.join(bank_schemes)}

Note: This is an indicative fallback. Final eligibility may vary by location, crop, and verification.
"""

    return offer_text
