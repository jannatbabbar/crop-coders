import joblib
import pandas as pd
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../')

# Paths
model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../model/credit_score_model.pkl')
label_encoders_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../model/label_encoders.pkl')

# Load Model & Label Encoders
model = joblib.load(model_path)
label_encoders = joblib.load(label_encoders_path)

# Feature Columns
categorical_fields = [
    "State", "District", "Season", "Education_Level", "Land_Ownership_Type",
    "Crop_Grown", "Loan_Status", "Access_to_Irrigation", "Insurance_Availed",
    "District_Weather", "Crop_Season_Shock", "Modern_Agri_Techniques_Used",
    "Loan_Taken", "Horticulture_Farmer", "FPO_Member", "Outlier_Flag"
]

numeric_fields = [
    'Farmer_Age', 'Landholding_Size_ha', 'Crop_Risk_Score', 'Crop_Yield_kg_per_ha',
    'Sale_Price_per_kg', 'Gross_Income', 'Input_Cost', 'Net_Income',
    'Monthly_Family_Expense', 'Net_Disposable_Income', 'Off_Farm_Income'
]

feature_cols = numeric_fields + categorical_fields

# Score Mapping Functions
def map_score(raw_score):
    return 300 + (raw_score / 10) * 600

def adjust_score(predicted_score, modern_tech_used):
    if modern_tech_used == "Yes":
        return min(900, predicted_score + 15)
    else:
        return predicted_score

def preprocess_input_data(input_data):
    # Ensure dictionary
    if not isinstance(input_data, dict):
        raise TypeError(f"Expected input_data to be a dictionary, but got {type(input_data).__name__}")

    # Map input data to expected feature names
    column_mapping = {col: col for col in numeric_fields + categorical_fields}
    processed_data = {col: input_data.get(col, None) for col in column_mapping}

    # Fill missing values
    for col in feature_cols:
        if processed_data[col] is None:
            processed_data[col] = "Unknown" if col in categorical_fields else 0
    return processed_data

def predict_credit_score(input_data):
    # Convert Row to dictionary if necessary
    if not isinstance(input_data, dict):
        if hasattr(input_data, "asDict"):  # Check if input_data has asDict method
            input_data = input_data.asDict()
        else:
            raise TypeError(f"Expected input_data to be a dictionary or Row, but got {type(input_data).__name__}")

    # Preprocess input
    processed_data = preprocess_input_data(input_data)
    df_input = pd.DataFrame([processed_data])

    # Encode categorical fields
    for col in categorical_fields:
        if col in df_input:
            values = df_input[col].astype(str)
            values[~values.isin(label_encoders[col].classes_)] = "Unknown"
            df_input[col] = label_encoders[col].transform(values)

    # Convert numeric fields
    for col in numeric_fields:
        df_input[col] = pd.to_numeric(df_input[col], errors='coerce').fillna(0)

    # Predict
    X_input = df_input[feature_cols]
    raw_pred = model.predict(X_input)[0]
    base_score = map_score(raw_pred)
    final_score = adjust_score(base_score, processed_data.get("Modern_Agri_Techniques_Used", "No"))
    return round(final_score)