# llama_integration.py

import requests

LLM_BACKEND = "openrouter"
OPENROUTER_API_KEY = "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"
LOCAL_LLM_ENDPOINT = "http://164.52.199.30:6000/gpu/generate-loan-offer"

def generate_llama_text(prompt):
    if LLM_BACKEND == "openrouter":
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "mistralai/mistral-7b-instruct",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7
        }
        
        # Send request to OpenRouter to generate the AI contract
        response = requests.post(url, headers=headers, json=payload)
        data = response.json()

        # Debug: Print the OpenRouter response to check for errors
        print("OpenRouter Response:", data)

        # Check for the contract text in the response
        if 'choices' in data:
            return data['choices'][0]['message']['content']
        else:
            print("LLM API Error Response:", data)
            return "Sorry, could not generate offer text."

    else:
        # Handle local LLaMA model integration
        response = requests.post(LOCAL_LLM_ENDPOINT, json={"prompt": prompt})
        data = response.json()

        # Debug: Print the local LLaMA response
        print("Local LLaMA Response:", data)

        # Check for contract text in the response
        if 'text' in data:
            return data['text']
        else:
            print("Local LLaMA Error Response:", data)
            return "Sorry, local LLaMA failed."

# --- Dynamic prompt for LOAN OFFERS ---
def build_loan_offer_prompt(farmer_details):
    credit_score = farmer_details.get('credit_score')
    net_income = farmer_details.get('net_income')
    caste = farmer_details.get('caste', 'General')
    gender = farmer_details.get('gender', 'Male')
    district = farmer_details.get('district', 'unknown')
    state = farmer_details.get('state', 'unknown')

    prompt = f"""
Suggest loan options for a {gender} farmer of {caste} category from {district}, {state} with credit score {credit_score} and annual income ₹{net_income}.
Provide 1x, 2x, 3x income loan amount ranges based on annual income ₹{net_income} and credit score {credit_score}. 
Mention recommended interest rates based on credit score.
4. Suggestions for crop-specific loans or subsidies (e.g., loans for horticulture, dairy farming, or cash crops).
5. Simple, human-readable bullet points for clarity.

Consider regional challenges faced by farmers in {district}, {state}, such as drought, floods, or market access issues, and suggest solutions or support programs.
Create simple, human-readable bullet points for clarity.
"""
    return prompt

# --- Dynamic prompt for AI CONTRACT ---
def build_ai_contract_prompt(contract_details):
    farmer_name = contract_details.get('farmer_name')
    lender_name = contract_details.get('lender_name')
    loan_amount = contract_details.get('loan_amount')
    interest_rate = contract_details.get('interest_rate')
    district = contract_details.get('district')
    state = contract_details.get('state')
    duration_months = contract_details.get('duration_months', 12)

    prompt = f"""
#Create a simple, legally valid loan agreement between a farmer and a lender.
# Try to incorporate the loan agreement or farming laws of the particular location.
# Check that the contract is not violating any regional or national laws.
# Check if there is any bias against or towards the farmer or the lender, if found any, highlight in the notes of the contract so that they can be reviewed by any of the parties.
# Use the following information to create the final contract.

- Farmer Name: {farmer_name}
- Lender Name: {lender_name}
- Loan Amount: ₹{loan_amount}
- Interest Rate: {interest_rate}% per annum
- Loan Duration: {duration_months} months
- Location: {district}, {state}

Include sections for:
- Brief introduction including 1) Parties to the agreement 2) Date of Agreement 3) Purpose of the loan
- Loan Details including 1) Loan amount 2) Interest rate 3) Repayment terms (Schedule and Method of payment)
- Disbursement Conditions
- Collateral and Security including 1) Description of collateral 2) Conditions for providing collateral 3) Right and responsibilities regarding collateral
- Conditions Precedent including 1) conditions for loan disbursement 2) Obligations of Borrower to Fulfill Conditions
- Events of Default including 1) definition of default 2) Consequences of default 3) Remedies for the lender
- Dispute resolution

Format the contract simply, avoiding complex legal language.
Return only the contract text and nothing extra.
"""
    return prompt
