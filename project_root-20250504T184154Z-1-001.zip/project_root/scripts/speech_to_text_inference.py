import requests

GPU_NODE_URL = "http://164.52.199.30:6000/"

def speech_to_text(audio_path, language_code=None):
    url = f"{GPU_NODE_URL}/gpu/speech-to-text"
    files = {'audio': open(audio_path, 'rb')}
    data = {'language': language_code} if language_code else {}
    
    try:
        response = requests.post(url, files=files, data=data)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
        try:
            return response.json().get('text', '')
        except ValueError:
            # Handle JSON decoding errors
            return "Error: Invalid JSON response from server."
    except requests.exceptions.RequestException as e:
        # Handle request exceptions
        return f"Error: {str(e)}"