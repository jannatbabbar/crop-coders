import sqlite3

# Connect (creates file if not exists)
conn = sqlite3.connect('db/farmers.db')
cursor = conn.cursor()

# Create Farmers Table (If needed again)
cursor.execute('''
CREATE TABLE IF NOT EXISTS farmers (
    Farmer_ID TEXT PRIMARY KEY,
    Farmer_Name TEXT,
    mobile_number TEXT,
    Season TEXT,
    Year INTEGER,
    State TEXT,
    District TEXT,
    Farmer_Age INTEGER,
    Gender TEXT,
    Caste TEXT,
    District_Weather TEXT,
    Average_Temperature_C REAL,
    Average_Rainfall_mm REAL,
    Education_Level TEXT,
    Land_Ownership_Type TEXT,
    Landholding_Size_ha REAL,
    Crop_Grown TEXT,
    Crop_Risk_Score REAL,
    Crop_Yield_kg_per_ha INTEGER,
    Sale_Price_per_kg REAL,
    Gross_Income INTEGER,
    Input_Cost INTEGER,
    Net_Income INTEGER,
    Monthly_Family_Expense INTEGER,
    Net_Disposable_Income INTEGER,
    Loan_Taken TEXT,
    Loan_Amount INTEGER,
    Loan_Status TEXT,
    Previous_Default TEXT,
    Loan_Purpose TEXT,
    Debt_to_Income_Ratio REAL,
    Insurance_Availed TEXT,
    Crop_Season_Shock TEXT,
    Insurance_Payout INTEGER,
    FPO_Member TEXT,
    Access_to_Irrigation TEXT,
    Machinery_Owned TEXT,
    Livestock_Owned TEXT,
    Secondary_Income_Source TEXT,
    Govt_Scheme_Beneficiary TEXT,
    External_Shock TEXT,
    Outlier_Flag TEXT,
    Horticulture_Farmer TEXT,
    Off_Farm_Income TEXT,
    Market_Access TEXT,
    Modern_Agri_Techniques_Used TEXT,
    Credit_Score INTEGER
)
''')

# Create Lenders Table
cursor.execute('''
CREATE TABLE IF NOT EXISTS lenders (
lender_id INTEGER PRIMARY KEY AUTOINCREMENT,
    lender_name TEXT,
    mobile_number TEXT,
    state TEXT,
    district TEXT
)
''')

# Create Loan Requests Table
cursor.execute('''
CREATE TABLE IF NOT EXISTS loan_requests (
    loan_request_id TEXT PRIMARY KEY,
    farmer_id TEXT,
    loan_amount INTEGER,
    interest_rate REAL,
    duration_in_months INTEGER,
    status TEXT DEFAULT 'requested',
    FOREIGN KEY (farmer_id) REFERENCES farmers(Farmer_ID)
)
''')


# Create Loan Offers Table
cursor.execute('''
CREATE TABLE IF NOT EXISTS loan_offers (
    offer_id TEXT PRIMARY KEY,
    lender_id TEXT,
    farmer_id TEXT,
    loan_request_id TEXT,
    offered_interest_rate REAL,
    status TEXT DEFAULT 'pending',
    FOREIGN KEY (lender_id) REFERENCES lenders(lender_id),
    FOREIGN KEY (loan_request_id) REFERENCES loan_requests(loan_request_id),
    FOREIGN KEY (farmer_id) REFERENCES farmers(Farmer_ID)
)
''')

conn.commit()
conn.close()

print("Database and tables created successfully!")
