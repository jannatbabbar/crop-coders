#!/bin/bash
sudo apt update -y
sudo apt install python3-pip -y
pip3 install -r requirements_gpu.txt

# Check if IndicTrans2 is already set up
if [ -d "IndicTrans2" ]; then
    echo "IndicTrans2 is already set up. Skipping installation."
    exit 0
fi

# Clone the IndicTrans2 repository
echo "Cloning IndicTrans2 repository..."
git clone https://github.com/AI4Bharat/IndicTrans2.git

# Run the installation script
echo "Running IndicTrans2 installation script..."
cd IndicTrans2/huggingface_interface/
bash install.sh
cd ../../  # Return to the root directory

echo "IndicTrans2 setup completed."

cd api_gpu
python3 app.py
